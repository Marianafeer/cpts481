Welcome to the CoronaGame game:

HOW TO RUN THE GAME:

import pygame
pip install requests
pip install beautifulsoup4
pip3 install bs4

python3 player.py

INSTRUCTIONS:

GOAL: Get all the cases depending on the random country you get
COVID CASES are gotten from an API using python library "BeautifulSoup" that give us the current cases in the country you are playing for.  

- 10pts to kill a virus
- You have only 3 opportunities to get touched by a virus, otherwise you die.
- You will get a different country and different background

Use right and left buttons to move the user and press space to kill the viruses! Have fun!
