#import graphical user interface(GUI) Pygame
import pygame
import random
from bs4 import BeautifulSoup as BS 
import requests

width = 864
height = 617

pygame.init()
pygame.mixer.init() #for music purposes
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("CoronaGame") # game Table name
clock = pygame.time.Clock()

#here we will add the background
backgrounds = []
allbackgrounds = ["images/background1.png", "images/background3.jpg", "images/background4.jpg", "images/background5.jpg"]
for img in allbackgrounds:
    backgrounds.append(pygame.image.load(img).convert())

background2 = pygame.image.load("images/background2.png").convert()
# load music here
vaccineSound = pygame.mixer.Sound("images/shoot.ogg")
killVirusSound = pygame.mixer.Sound("images/killvirus.mp3")
pygame.mixer.music.load("images/music.mp3")
pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play(-1)
# GameOver music
gameoversound = pygame.mixer.Sound("images/explosion.wav")

# country names available game
countries = ["US", "INDIA","SPAIN", "MEXICO", "BRAZIL", "FRANCE", "ITALY", "COLOMBIA", "GERMANY", "POLAND"]
'''
flags = []
countriesFlag = ["images/usflag.png", "images/spainflag.jpg"]
for img in countriesFlag:
    flags.append(pygame.image.load(img).convert())
'''
# method to get info cases per country
def getInfo(country_name):
    url = "https://www.worldometers.info/coronavirus/country/" + country_name + "/"
    data = requests.get(url)
    # converting the text
    soup = BS(data.text, 'html.parser')
    cases = soup.find_all("div", class_ = "maincounter-number") 
    # getting total cases number 
    total = cases[0].text
    # filtering it 
    total = total[1 : len(total) - 2] 

    return total

# here we draw the bar p = perentage
def drawHealthBar(surface, x, y, p):
    barheight = 20
    barlength = 150
    fillbar = (p / 100 ) * barlength # regla de tres para saber porcentage
    border =  pygame.Rect(x,y, barlength, barheight)
    fillbar = pygame.Rect(x,y, fillbar, barheight)
    pygame.draw.rect(surface,(0,255,0) ,fillbar) # green color
    pygame.draw.rect(surface, (255,255,255), border, 2)

def drawMyscore(surface, text, size, x, y):
    font = pygame.font.SysFont(None, size)
    textSurface = font.render(text, True, (255, 255, 255) )
    textRect = textSurface.get_rect()
    textRect.midtop = (x,y)
    surface.blit(textSurface, textRect)

def drawInstructions(surface, text, size, x, y):
    font = pygame.font.SysFont(None, size)
    textSurface = font.render(text, True, (205,92,92) )
    textRect = textSurface.get_rect()
    textRect.midtop = (x,y)
    surface.blit(textSurface, textRect)

# sprites is a two-dimensional bitmap that is integrated into a larger scene
# class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("images/player.png").convert()
        self.image.set_colorkey((0,0,0)) # black
        self.rect = self.image.get_rect()
        self.rect.centerx = width // 2
        self.rect.bottom = height 
        self.speed = 0
        self.protection = 100
    
    def update(self):
        self.speed = 0
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            self.speed = -5
        if key[pygame.K_RIGHT]:
            self.speed = 5
        self.rect.x += self.speed
        # base cases when we move our doctor image, to make sure it does not come out of the screen
        if self.rect.right > width:
            self.rect.right = width
        if self.rect.left < 0:
            self.rect.left = 0
    
    def kill(self):
        vaccine = Vaccine(self.rect.centerx, self.rect.top)
        allSprites.add(vaccine)
        vaccines.add(vaccine)
        vaccineSound.play() # this method would play the sound


class Virus(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = random.choice(virusready)
        self.image.set_colorkey((0,0,0))
        self.rect = self.image.get_rect()
        #here we want the virus to start from a random place in the screen
        self.rect.x = random.randrange(width - self.rect.width)
        self.rect.y = random.randrange(-140, -100) # gravity
        self.speedy = random.randrange(1,8) # random speed coming down
        # viruses are moving down but here we will add a movement in x as well
        self.speedx = random.randrange(-5, 5)

#updates movement of the class Virus, virus itself
    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        # base cases when the virus leaves the screen (left or right)
        if self.rect.left < -40 or self.rect.right > width + 40  or self.rect.top > height + 10:
            # here we want to bring back the virus and repeat the same process
            self.rect.x = random.randrange(width - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1,10)
'''
class GreenVirus(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("images/viruspink.png").convert()
        self.image.set_colorkey((0,0,0))
        self.rect = self.image.get_rect()
        #here we want the virus to start from a random place in the screen
        self.rect.x = random.randrange(width - self.rect.width)
        self.rect.y = random.randrange(-100, -40) # gravity
        self.speedy = random.randrange(1,6) # random speed coming down
        # viruses are moving down but here we will add a movement in x as well
        self.speedx = random.randrange(-5, 5)

#updates movement of the class Virus, virus itself
    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        # base cases when the virus leaves the screen (left or right)
        if self.rect.left < 15 or self.rect.right > width + 10  or self.rect.top > height + 10:
            # here we want to bring back the virus and repeat the same process
            self.rect.x = random.randrange(width - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1,10)
'''
class Vaccine(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("images/vaccine.png")
        self.rect = self.image.get_rect()
        self.image.set_colorkey((0,0,0))
        # x and y of the vaccine
        self.rect.y = y
        self.rect.x = x
        self.rect.centerx = x
        self.speedy = - 10 # it needs to start from the bottom and negative to go up
    def update(self):
        # we need it to go up
        self.rect.y += self.speedy
        # once the vaccine get a virus we want to delete it or it gets out of the
        # screen
        if self.rect.bottom < 0:
            # delete all the instances of this object
            self.kill()
# gameover screen
def showGameOver():
    gameoversound.play()
    #get country name
    country_name = random.choice(countries)
    countryCases = getInfo(country_name)
    print(countryCases)
    print(country_name)

    screen.blit(background2, [0,0])
    drawMyscore(screen, "Your Country " + country_name , 80, width //2, height - 600)
    drawInstructions(screen, "COVID Cases: " + countryCases , 60, width //2, height - 548)
    drawMyscore(screen, "YOUR GOAL: " + countryCases + " GOOD LUCK!" , 50, width //2, height - 250)
    drawMyscore(screen, "PRESS ENTER TO START" , 65, width //2, height - 100)
    
    pygame.display.flip() # show it in screen

    waiting = True
    while waiting:
        clock.tick(60)
        # check what the user clicks on
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit ()
            if e.type == pygame.KEYDOWN: # button was pressed so we check for KEYUP
                if e.key == pygame.K_RETURN:
                    waiting = False 
    
    return countryCases

# list with all the type of viruses
virusready = []
viruses = ["images/virus.png", "images/viruspink.png", "images/virusgreen.png", "images/coronaPink.png"]

for img in viruses:
    virusready.append(pygame.image.load(img).convert())

#pygame.mixer.music.play(Loops = -1) # play music all the time infinite

running = True
gameOver = True
background = random.choice(backgrounds)

# while there is not collision or I have not got the virus
while running:    
    if gameOver or (score == countryCases):
        countryCases = showGameOver()
        gameOver = False
        background = random.choice(backgrounds)

        #GROUPS OF OBJECTS
        allSprites = pygame.sprite.Group() # here we will add the player and the viruses
        allVirus = pygame.sprite.Group() # group the viruses
        vaccines = pygame.sprite.Group()
        # player instance 
        player = Player()
        allSprites.add(player)

        #viruses instances, we will add 7 viruses each for now
        #it also needs to be added in the sprites group
        for i in range(10):
            virus = Virus()
            # greenvirus = GreenVirus() DECIDED TO DO IT IN DIFFERENT WAY BUT CANT DELETE IT JUST IN CASE
            allSprites.add(virus)
            allVirus.add(virus)
            #allSprites.add(greenvirus)
            #allVirus.add(greenvirus)

        score = 0

    clock.tick(60) # 60 rects per second
    


    # if we stoped the game with change our variable running to False
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        # allows the user to send the vacinne to kill the virus
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_SPACE:
                player.kill()

    # pygame update() method not mine
    allSprites.update()

    # collisions: virus - vaccine
    #groupcollide checks the collisions between two groups
    collisions = pygame.sprite.groupcollide(allVirus, vaccines, True, True)
    for collision in collisions:
        # End of game, user wins
        # here we want to make sure that once there is a collision
        # the sprites will disapear from their current position
        # and appear again on top to keep the game going on
        score += 10
        killVirusSound.play()
        virus = Virus()
        #greenvirus = GreenVirus()
        allSprites.add(virus)
        allVirus.add(virus)
        # allSprites.add(greenvirus)
        #allVirus.add(greenvirus)


    # here we are going to check when there is a collision
    collisions = pygame.sprite.spritecollide(player, allVirus, True)
    # we are going to allow the user to get the bacteria a few times before dying 
    for collision in collisions:
        player.protection -= 25
        # create a virus everytime a get hit (before dying)
        virus = Virus()
        allSprites.add(virus)
        allVirus.add(virus)
        # it means that I got the virus
        if player.protection <= 0:
            #running = False 
            gameOver = True

    #screen.fill() 
    # put background
    screen.blit(background, [0,0 ]) # [0,0] location
    
    #draw our sprites in the screen
    allSprites.draw(screen)


    # here we place our score function
    drawInstructions(screen, "GOAL " + countryCases, 60, width // 2 , 5)
    drawMyscore(screen, "CASES" , 40, width -80, 20)
    drawMyscore(screen, str(score), 70, width -80, 40)
    # user has protection can get a collision upt to 2 times - third one dies
    drawHealthBar(screen, 10, 10, player.protection)

    pygame.display.flip() 

# once running = False
# stop playing
pygame.quit()